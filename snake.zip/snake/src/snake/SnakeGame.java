
package snake;

import java.io.File;
import javax.sound.sampled.*;
import javax.swing.*;
 
public class SnakeGame {
public static void main(String[] args) throws InterruptedException {
int run = 0;
do { 
JFrame f=new JFrame();
f.setBounds(0, 0, 700, 500);
game g=new game();
  try {
        AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new File(g.music).getAbsoluteFile());
        Clip clip = AudioSystem.getClip();
        clip.open(audioInputStream);
        clip.start();
        clip.loop(100);
          
f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
f.add(g);
f.setVisible(true);

g.ballMoves(); 

run = JOptionPane.showConfirmDialog(null,
                   "Would you like to play again?", //Boolean question - good choice for play-again scenario.
                    "Again?", //Dialog box name.
                    JOptionPane.YES_NO_OPTION); //Give user option to go again or not.

f.dispose();  
clip.stop();
  } catch(Exception ex) {
        System.out.println("Error with playing sound.");
      //ex.printStackTrace();
    }
} while (run == 0); //Loop condition.

        
  
        

    }
    
}
