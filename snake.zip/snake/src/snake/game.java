
package snake;

import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Random;
import javax.swing.*;
import javax.imageio.*;
import javax.sound.sampled.*;
import javax.swing.border.LineBorder;



public class game extends JPanel  {
    
    
    boolean hit;
    
      //paths       
    String HeadPath = "snake2.jpg";
    String BodyPath = "body.jpg";
    String BlockPath = "block.gif";
    String FruitPath  = "cherry.png";
    String BGPath =  "BG.png";
    String BorderPath = "block.gif";
    String music ="music.wav";

    //arrayslists
    ArrayList<Integer>y=new ArrayList<Integer>();
    ArrayList<Integer>x=new ArrayList<Integer>(); 
    
    ArrayList<Integer>ySquare=new ArrayList<Integer>();
    ArrayList<Integer>xSquare=new ArrayList<Integer>(); 

    // our coordinates for the square
    private int squareX;
    private int squareY;
    private int squareW ;
    private int squareH ;
    //our coordinates for the bouders 
    private int rectX ;
    private int rectY;
    private int rectW ;
    private int rectH ;
    //score label and value
    JLabel scoreLabel;
    int score;
    //tol el snake
    int snakeLength; 
    //to stop the game
    boolean done;
    
    String key;
    // to genrate random numbers
    Random r;
    //our apple
    int xApple;
    int yApple;
    // to make sure the the snake doesn't go opposite direction
    boolean up,down,left,right; 
    game() throws InterruptedException{
    xApple=90;
    yApple=90;
    
    hit=false;
    
    r = new Random();
    
    squareX = 50;
    squareY = 50;
    squareW = 20;
    squareH = 20;
    
    rectX = 0;
    rectY = 0;
    rectW = 700;
    rectH = 500;
    
    scoreLabel=new JLabel();
    score=0;
    scoreLabel.setText("Score: "+score);
    scoreLabel.setBounds(590, 440, 100, 30);
    scoreLabel.setBorder(new LineBorder(Color.BLACK, 3));
    this.add(scoreLabel);
    
    done=false;
    
    up=true;
    
    key="up";
    
    snakeLength=1;
    
    x.add(350);
    y.add(200);
    
    for(int i=0;i<100000;i++){
    x.add(1);
    y.add(1);
    if(i<10){
    xSquare.add(0);
    ySquare.add(0);
    }
    }
    
    this.setLayout(null);
    this.setBounds(0, 0, 700, 500);
    this.setBorder(new LineBorder(Color.RED,3));
    this.addKeyListener(new keyList());
    }

      
  public void paintComponent(Graphics g){
     super.paintComponent(g);   
     try { BufferedImage Background = ImageIO.read(new File(BGPath));
     g.drawImage(Background, rectX, rectY, 700, 500, null);
              
      BufferedImage Block = ImageIO.read(new File(BlockPath));
      
      for(int i=0;i<4;i++){
      g.drawImage(Block, xSquare.get(i), ySquare.get(i),50,30, null);
      }
                                 
      BufferedImage fruit = ImageIO.read(new File(FruitPath));
      g.drawImage(fruit, xApple, yApple,30,30, null);
   
      } catch (Exception e) {
      }
       g.setColor(Color.red);
       g.drawRect(rectX,rectY,rectW,rectH);
       g.fillOval(x.get(0), y.get(0), 10, 10);
       g.setColor(Color.blue);
       for(int i=2;i<=snakeLength;i++){
       g.fillOval(x.get(i), y.get(i), 10, 10);  
       }
        this.addKeyListener(new keyList());
   }

 private class keyList extends KeyAdapter
    {
     
     public void keyPressed(KeyEvent e){
         if(e.getKeyCode()==KeyEvent.VK_UP){
             key="up";
         }else if(e.getKeyCode()==KeyEvent.VK_DOWN){
             key="down";
       }  else if(e.getKeyCode()==KeyEvent.VK_LEFT){
             key="left";
       }  else if(e.getKeyCode()==KeyEvent.VK_RIGHT){
            key="right";
       }       
       
     }
 }
 
  public void ballMoves() throws InterruptedException{
  this.setFocusable(true);

  while(true){
      
     switch(key){
        case "up":
         if(up){
         down=false;
         right=true;
         left=true; 
         }
         break;
         
      //************
         
         case "down":
         if(down){
         up=false;
         right=true;
         left=true;  
         }
         break;
         
      //************
         
         case "left":
         if(left){
         right=false;
         up=true;
         down=true;
        }
         break;
         
      //************
         
        case"right": 
        if(right){
         left=false;
         down=true;
         up=true;
         }  
         break;
         
      //************
         
         default:
         break;
     }
     if(up==true&&down==false){
        y.set(0, y.get(0)-10);   
     }
     else if(down==true&&up==false){
       y.set(0, y.get(0)+10);   
     }
     else  if(left==true&&right==false){
       x.set(0, x.get(0)-10);  

     }
     else if(right==true&&left==false){
       x.set(0, x.get(0)+10);   
     }
     if(hit){
     break;
      }
   
      collesion();
      newPos();
      checkSnake();
      Thread.sleep(100);
      repaint();
      checkStatus();
      if(done){
      JOptionPane.showMessageDialog(null, "You Lost Your Score is :"+score,"lost", JOptionPane.INFORMATION_MESSAGE);
      break;
      }
      
  }}
  
  
    public void newPos(){ 
            //shift to move body in last place of head
             for(int i=snakeLength;i>=0;i--){
             x.set(i+1, x.get(i));
             y.set(i+1, y.get(i));
    }}
    
    
    public void collesion(){
            //  check collesion between head and apple
            if(x.get(0) == xApple && y.get(0) == yApple || x.get(0) >= xApple && x.get(0) <= xApple +20  && y.get(0) >= yApple && y.get(0) <= yApple +20 ){
                while(true){  
                xApple=r.nextInt(70)*10; 
                yApple=r.nextInt(20)*10; 
                //get new coordinate for the apple and make sure it will not appear on the snake or out of bouders
            if(!x.contains(xApple)&&!y.contains(yApple)&&xApple<=670&&xApple>=20&&yApple<=480&&yApple>=20){
                break; 
                }
                } 
                
                for(int i=0;i<4;i++){
                while(true){          
                xSquare.set(i,r.nextInt(60)*10);
                ySquare.set(i,r.nextInt(19)*10);

                //to make sure that the rock doesn't override  the apple or the snake head only in the painting
                if(!x.contains(xSquare.get(i))&&!y.contains(ySquare.get(i))&&xApple<xSquare.get(i)||xApple>(xSquare.get(i)+40)&&yApple<ySquare.get(i)||yApple>(ySquare.get(i)+20)){                
                if( x.get(0)>(xSquare.get(i)+70)||x.get(0)<(xSquare.get(i)-70)&&y.get(0)>(ySquare.get(i)+70)||y.get(0)<(ySquare.get(i)-70)){
                      break;
                }}
        
                }
                }
                score+=10;
                scoreLabel.setText("Score: "+score);
                snakeLength++;
                }            
            }  
         public void checkStatus(){
         for(int i=0;i<4;i++){
         //to check if the snake hit the rock
         if(xSquare.get(i)<=x.get(0)&& x.get(0)<=(xSquare.get(i)+40)&&ySquare.get(i)<=y.get(0)&& y.get(0)<=(ySquare.get(i)+20)){
             done=true;
         }
         }
         // to check if the snake hit the bouders
         if(x.get(0).equals(rectW)||y.get(0).equals(rectH)||x.get(0).equals(rectX)||y.get(0).equals(rectY))
         {
             done=true;
         }
         
         
         
    }
//to check that the snake hit his self or not
      public void checkSnake(){
        for(int i =snakeLength; i >2 ; i--) {
       
         if(x.get(0).equals( x.get(i)) && y.get(0) .equals(y.get(i))) {
             hit=true;
         
         }
         }
         }
      }
